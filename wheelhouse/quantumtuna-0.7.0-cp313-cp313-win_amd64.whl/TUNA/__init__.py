"""

TUNA

~~~~ Theoretical Unification of Nuclear Arrangements ~~~~

A user-friendly quantum chemistry program for diatomics.

"""

__version__ = "0.7.0"
__author__ = "Harry Brough"
